package com.diamondrealm;

import net.fabricmc.api.ModInitializer;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;

public class DiamondRealmMod implements ModInitializer {
	public static final String MOD_ID = "diamondrealm";
	public static final RegistryKey<World> REALM =
			RegistryKey.of(RegistryKeys.WORLD, Identifier.of(MOD_ID, "diamond_realm"));

	@Override
	public void onInitialize() {
		ModItems.register();
	}
}
