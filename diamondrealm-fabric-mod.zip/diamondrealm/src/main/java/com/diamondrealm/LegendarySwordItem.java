package com.diamondrealm;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;

public class LegendarySwordItem extends SwordItem {
	public LegendarySwordItem(Settings settings) {
		super(LegendaryMaterial.INSTANCE, settings.attributeModifiers(
				SwordItem.createAttributeModifiers(LegendaryMaterial.INSTANCE, 4, -2.2f)));
	}

	@Override
	public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
		target.setOnFireFor(6);
		target.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 200));
		target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 1));
		return super.postHit(stack, target, attacker);
	}
}
