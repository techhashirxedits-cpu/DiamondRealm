package com.diamondrealm;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

/** Right-click: Overworld <-> Diamond Realm. */
public class DiamondBottleItem extends Item {
	public DiamondBottleItem(Settings settings) { super(settings); }

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
		ItemStack stack = player.getStackInHand(hand);
		if (!world.isClient && player instanceof ServerPlayerEntity sp) {
			MinecraftServer server = sp.getServer();
			RegistryKey<World> targetKey = world.getRegistryKey().equals(DiamondRealmMod.REALM)
					? World.OVERWORLD : DiamondRealmMod.REALM;
			ServerWorld target = server.getWorld(targetKey);
			if (target == null) {
				sp.sendMessage(Text.literal("Diamond Realm dimension not found!"), true);
				return TypedActionResult.fail(stack);
			}
			int x = sp.getBlockX(), z = sp.getBlockZ();
			target.getChunk(x >> 4, z >> 4);
			int y = target.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
			sp.teleport(target, x + 0.5, y, z + 0.5, sp.getYaw(), sp.getPitch());
			sp.getItemCooldownManager().set(this, 100);
		}
		return TypedActionResult.success(stack, world.isClient());
	}
}
