package com.diamondrealm;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.*;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModItems {
	static final LegendaryMaterial M = LegendaryMaterial.INSTANCE;

	public static final Item DIAMOND_BOTTLE = reg("diamond_bottle",
			new DiamondBottleItem(new Item.Settings().maxCount(1).rarity(Rarity.EPIC)));
	public static final Item LEGENDARY_SWORD = reg("legendary_sword",
			new LegendarySwordItem(new Item.Settings().rarity(Rarity.EPIC).fireproof()));
	public static final Item LEGENDARY_PICKAXE = reg("legendary_pickaxe",
			new PickaxeItem(M, new Item.Settings().rarity(Rarity.EPIC).fireproof()
					.attributeModifiers(PickaxeItem.createAttributeModifiers(M, 1.0f, -2.8f))));
	public static final Item LEGENDARY_AXE = reg("legendary_axe",
			new AxeItem(M, new Item.Settings().rarity(Rarity.EPIC).fireproof()
					.attributeModifiers(AxeItem.createAttributeModifiers(M, 5.0f, -3.0f))));
	public static final Item LEGENDARY_SHOVEL = reg("legendary_shovel",
			new ShovelItem(M, new Item.Settings().rarity(Rarity.EPIC).fireproof()
					.attributeModifiers(ShovelItem.createAttributeModifiers(M, 1.5f, -3.0f))));

	private static Item reg(String name, Item item) {
		return Registry.register(Registries.ITEM, Identifier.of(DiamondRealmMod.MOD_ID, name), item);
	}

	public static void register() {
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> {
			e.add(DIAMOND_BOTTLE); e.add(LEGENDARY_SWORD); e.add(LEGENDARY_PICKAXE);
			e.add(LEGENDARY_AXE); e.add(LEGENDARY_SHOVEL);
		});
	}
}
