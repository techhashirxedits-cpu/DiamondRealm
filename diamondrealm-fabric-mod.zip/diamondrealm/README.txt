Build: JDK 21 + Gradle, then `gradle build` in this folder.
Easier: get the Fabric template from fabricmc.net/develop/template, copy this project's
src/ folder and gradle.properties over it, run ./gradlew build.
Jar: build/libs/diamondrealm-1.0.0.jar -> .minecraft/mods (with Fabric API for 1.21.1).
Test dimension: /execute in diamondrealm:diamond_realm run tp @s ~ 120 ~
